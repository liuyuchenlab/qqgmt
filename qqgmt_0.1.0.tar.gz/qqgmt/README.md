
# qqgmt

<!-- badges: start -->
<!-- badges: end -->

The goal of qqgmt is to ...

## Installation

You can install the development version of qqgmt like so:

``` r
# FILL THIS IN! HOW CAN PEOPLE INSTALL YOUR DEV PACKAGE?
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(qqgmt)
## basic example code
```

